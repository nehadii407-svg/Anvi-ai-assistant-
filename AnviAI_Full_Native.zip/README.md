# Anvi AI — Full Native Android Starter

One project, not separate pieces.

Included:
- Hindi/English voice input and TTS
- Conversation text on screen
- Local command/action layer
- Google/YouTube/search
- Android Settings/Wi-Fi/Bluetooth
- SMS message draft with explicit confirmation
- Accessibility service boundary
- PrivacyGuard that blocks PIN/OTP/password/CVV/payment-secret phrases before logging
- No screenshot/recording/keylogging implementation
- Protected payment/authentication automation intentionally excluded

Important:
This is a buildable native Android starter architecture. A true always-on “Hey Anvi”
wake-word requires a dedicated on-device wake-word engine and Android foreground-service
implementation. Open-ended AI requires an AI model/backend; the app should never contain
a private API key. Full Android control is constrained by Android permissions and security.

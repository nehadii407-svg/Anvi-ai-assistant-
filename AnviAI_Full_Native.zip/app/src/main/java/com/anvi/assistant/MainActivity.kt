package com.anvi.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var answer: TextView
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var input: EditText
    private val speechReq=1001
    private var pendingMessage: String? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_main)
        answer=findViewById(R.id.answer); status=findViewById(R.id.status); log=findViewById(R.id.log); input=findViewById(R.id.input)
        tts=TextToSpeech(this,this)
        findViewById<Button>(R.id.mic).setOnClickListener { listen() }
        findViewById<Button>(R.id.send).setOnClickListener { val q=input.text.toString(); input.text.clear(); runCommand(q) }
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),1002)
    }
    override fun onInit(s:Int){ if(s==TextToSpeech.SUCCESS) tts.language=Locale("hi","IN") }

    private fun listen(){
        val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale("hi","IN"))
            putExtra(RecognizerIntent.EXTRA_PROMPT,"Hey Anvi… बोलिए")
        }
        startActivityForResult(i,speechReq)
    }
    override fun onActivityResult(r:Int,c:Int,d:Intent?){
        super.onActivityResult(r,c,d)
        if(r==speechReq && c==RESULT_OK) d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let(::runCommand)
    }
    private fun say(s:String){ answer.text=s; tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"anvi") }
    private fun addUser(q:String){ log.append("\nYou: $q\n") }
    private fun addAnvi(q:String){ log.append("Anvi: $q\n") }

    private fun runCommand(q:String){
        if(q.isBlank()) return
        if(PrivacyGuard.isSensitive(q)){
            val r="Privacy mode: PIN, OTP, password, CVV और payment secrets को मैं process या save नहीं करूँगी।"
            addAnvi(r); say(r); return
        }
        val x=q.lowercase(Locale.getDefault()); addUser(q)
        when {
            x.contains("confirm message")||x.contains("कन्फर्म मैसेज") -> confirmMessage()
            x.contains("cancel message")||x.contains("मैसेज कैंसल") -> { pendingMessage=null; say("Message cancel कर दिया।") }
            x.contains("message")||x.contains("मैसेज")||x.contains("संदेश") -> prepareMessage(q)
            x.contains("नमस्ते")||x.contains("hello") -> sayAndLog("नमस्ते! मैं Anvi हूँ। बताइए।")
            x.contains("समय")||x.contains("time") -> sayAndLog("अभी "+SimpleDateFormat("hh:mm a",Locale("hi","IN")).format(Date())+" है।")
            x.contains("तारीख")||x.contains("date") -> sayAndLog("आज "+SimpleDateFormat("dd MMMM yyyy",Locale("hi","IN")).format(Date())+" है।")
            x.contains("youtube")||x.contains("यूट्यूब") -> {sayAndLog("YouTube खोल रही हूँ।"); open("https://www.youtube.com")}
            x.contains("google")||x.contains("गूगल") -> {sayAndLog("Google खोल रही हूँ।"); open("https://www.google.com")}
            x.contains("search")||x.contains("सर्च")||x.contains("खोज") -> {
                val term=q.replace(Regex("(?i)search|सर्च|खोज|करो|करें"),"").trim()
                if(term.isEmpty()) sayAndLog("क्या search करना है?") else {sayAndLog("Search कर रही हूँ।");open("https://www.google.com/search?q="+Uri.encode(term))}
            }
            x.contains("setting")||x.contains("सेटिंग") -> {sayAndLog("Settings खोल रही हूँ।");startActivity(Intent(Settings.ACTION_SETTINGS))}
            x.contains("wifi")||x.contains("वाईफाई") -> {sayAndLog("Wi‑Fi settings खोल रही हूँ।");startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))}
            x.contains("bluetooth")||x.contains("ब्लूटूथ") -> {sayAndLog("Bluetooth settings खोल रही हूँ।");startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))}
            x.contains("help")||x.contains("मदद") -> sayAndLog("मैं voice, messages, search, apps और supported phone actions कर सकती हूँ।")
            else -> sayAndLog("मैंने सुना: $q. इस build में local actions उपलब्ध हैं।")
        }
    }
    private fun sayAndLog(s:String){addAnvi(s);say(s)}
    private fun prepareMessage(q:String){
        val body=q.replace(Regex("(?i)hey anvi|anvi|message|मैसेज|संदेश|भेजो|भेजना है|करो"),"").trim()
        if(body.isEmpty()){sayAndLog("किसे और क्या message भेजना है, बताइए।");return}
        pendingMessage=body
        sayAndLog("Message तैयार है: $body. भेजने के लिए “confirm message” बोलिए।")
    }
    private fun confirmMessage(){
        val body=pendingMessage ?: run{sayAndLog("कोई pending message नहीं है।");return}
        pendingMessage=null
        val i=Intent(Intent.ACTION_SENDTO).apply{data=Uri.parse("smsto:");putExtra("sms_body",body)}
        sayAndLog("Messaging app खोल रही हूँ।");startActivity(i)
    }
    private fun open(u:String){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u)))}
    override fun onDestroy(){tts.shutdown();super.onDestroy()}
}
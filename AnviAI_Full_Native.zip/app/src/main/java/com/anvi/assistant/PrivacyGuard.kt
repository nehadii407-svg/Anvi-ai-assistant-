package com.anvi.assistant

object PrivacyGuard {
    private val blocked = listOf(
        "otp","one time password","password","पासवर्ड","pin","upi pin","cvv",
        "card number","कार्ड नंबर","atm pin","verification code","ओटीपी","पिन"
    )
    fun isSensitive(text: String): Boolean =
        blocked.any { text.lowercase().contains(it) }
}
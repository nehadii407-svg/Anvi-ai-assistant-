package com.anvi.assistant
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class AnviAccessibilityService : AccessibilityService() {
    private val protectedHints = listOf("upi","bank","payment","otp","password","pin","cvv")
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally do not read or log window text.
        // Protected payment/authentication automation is not implemented.
    }
    override fun onInterrupt() {}
}